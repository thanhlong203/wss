$(document).ready(function() {
  // Session Themes
  var usersession = "membersession";
  var login = "login";
  var logout = "logout";
  var btnLogin = $(".membertools li.btnMemberTools");
  var memberdropdown = $(".membertools li.memberlogged");

  //member logged   
  if ($.session.get(usersession)=="login") {
    btnLogin.addClass("hidden");
    btnLogin.addClass("hidden");
    memberdropdown.removeClass("hidden");
  }else{
    btnLogin.removeClass("hidden");
    memberdropdown.addClass("hidden");
  }
  
  $("#btnLoginAsMember").click(function(){
    $.session.set(usersession,login);  
  });
  $("#btnLogoutMember").click(function(){
    $.session.set(usersession,logout);  
  });

});
