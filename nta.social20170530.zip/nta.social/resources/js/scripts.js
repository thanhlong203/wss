$(document).ready(function() {
  //Manhpd updated 2016/03/10 
  //Load more click animation
  $("#btnLoadmore").click(function(){
    $parent = $(this).parent(".loadmore");
    $parent.addClass("loading");
    setInterval(function(){ 
      $parent.removeClass("loading");
    }, 10000); 
  });   
  //search currency pair 
  $("#searchCurrency").keyup(function(){    
    var filter = $(this).val(), count = 0;
    $(".currency-pair-list li").each(function(){
      if ($(this).attr('data-key').search(new RegExp(filter, "i")) < 0) {
        $(this).fadeOut();
      } else {
        $(this).show();
        count++;
      }
    });
    $("#searchCurrencyClear").removeClass('hidden');
  });  
  $("#searchCurrencyClear").click(function(){
     $("#searchCurrency").val('').trigger("keyup");
     $(this).addClass('hidden');
  });
  //checkbox & radionbutton group search
  if ($("input[type='radio'][data-group='search']").is(':checked')) {
    $("input[type='checkbox'][data-group='search']").prop('checked', false);
  }
  var statusSearch = false;
  $("input[type='checkbox'][data-group='search']").each(function() {
    if($(this).is(':checked')){
      statusSearch = true;
    }
  });  
  if (statusSearch) {
    $("input[type='checkbox'][data-group='search']").trigger("keyup");
  }
  $("input[type='checkbox'][data-group='search']").click(function(){
    $("input[type='radio'][data-group='search']").prop('checked',false);
  });
  $("input[type='radio'][data-group='search']").click(function(){
    $("input[type='checkbox'][data-group='search']").prop('checked',false);
  });
  
  //checkbox & radionbutton group attack
  if ($("input[type='radio'][data-group='attack']").is(':checked')) {
    $("input[type='checkbox'][data-group='attack']").prop('checked', false);
  }
  var statusAttack = false;
  $("input[type='checkbox'][data-group='attack']").each(function() {
    if($(this).is(':checked')){
      statusAttack = true;
    }
  });  
  if (statusAttack) {
    $("input[type='checkbox'][data-group='attack']").trigger("keyup");
  }
  $("input[type='checkbox'][data-group='attack']").click(function(){
    $("input[type='radio'][data-group='attack']").prop('checked',false);
  });
  $("input[type='radio'][data-group='attack']").click(function(){
    $("input[type='checkbox'][data-group='attack']").prop('checked',false);
  });

  //dropdown
  $("body select.msdropdown").msDropDown();

  // create modal popup for remove one guru diffirent
  $('#confirmOnceModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var dataidremove = button.attr('data-id');
    var modal = $(this);
    modal.find('.mavatar img').attr("src","resources/img/user/"+dataidremove+".jpg");
  });

  $("#mdescreption").click(function(){
    $(this).parents(".userinfogroup").toggleClass("show");
  });
  $("#hide-mdescreptiondetails").click(function(){
    $("#mdescreption").trigger("click");
  });

  // manhpd fixed trade settings
  // remove all current guru
  $(".removeallcurrentguru").on("click", function(){    
    $("ul[group='userlistmore']").append($("ul[group='userlist']").html());
    $("ul[group='userlist'] > li").remove();
    currentGuru(); 
    updateNumberGuru();
  });

  $(".modalremoveallguru").click(function(){
    $('#confirmRemoveAllGuruModal').modal('hide');
    $("ul[group='userlistmore']").append($("ul[group='userlist']").html());
    $("ul[group='userlist'] > li").remove();
    currentGuru();
    updateNumberGuru();
  });

  // create modal popup for remove one guru diffirent
  $('#confirmRemoveGuruModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var dataidremove = button.attr('data-id');
    var modal = $(this);
    modal.find('.modalremoveguru').attr("data-id",dataidremove);
  })   
  // remove one guru diffirent
  $(".modalremoveguru").click(function(){
    $('#confirmRemoveGuruModal').modal('hide');
    removeGuru($(this).attr("data-id"));
    updateNumberGuru();
  });

  //create modal popup for add one guru diffirent
  $('#addGuruModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var dataidadd = button.attr('data-id');
    var modal = $(this);
    modal.find('.modaladdguru').attr("data-id",dataidadd);
  })   
  // add one guru diffirent
  $(".modaladdguru").click(function(){
    $('#addGuruModal').modal('hide');
    addGuru($(this).attr("data-id"));
    updateNumberGuru();
  }); 
  // slider Jquery UI
  $(function() {  
    //Earning rate  収益率：0,5,10,20,30,40,50,60,70,80,90,100,150,200,∞
    var earning_rate = ["0","5","10","20","30","40","50","60","70","80","90","100","150","200","∞"];
    $("#slider-range-1").slider({
      range: true,
      min: 0,
      max: earning_rate.length - 1,
      step: 1,
      values: [2, 8],
      slide: function(event, ui) {
        $("#amountup-1").val(earning_rate[ui.values[0]]);
        $("#amountdown-1").val(earning_rate[ui.values[1]]);
      }
    });
    $("#amountup-1").val(earning_rate[$("#slider-range-1").slider("values", 0)]);
    $("#amountdown-1").val(earning_rate[$("#slider-range-1").slider("values", 1)]);

    //Maximum loss rate 最大損失率： 0, 5, 10, 20, 30, 40, 50, 100
    var loss_rate = [0, 5, 10, 20, 30, 40, 50, 100];
    $("#slider-range-2").slider({
      //min: 0,
      range: "min",
      min:0,      
      max: loss_rate.length - 1,
      step: 1,
      value: 2,
      slide: function(event, ui) {
        $("#amountdown-2").val(loss_rate[ui.value]);
      }
    });
    $("#amountup-2").val(0);
    $("#amountdown-2").val(loss_rate[$("#slider-range-2").slider("values", 1)]);

    //Winning percentage: 勝率 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
    $("#slider-range-3").slider({
      range: true,
      min: 0,
      max: 100,
      step: 10,
      values: [10, 70],
      slide: function(event, ui) {
        $("#amountup-3").val(ui.values[0]);
        $("#amountdown-3").val(ui.values[1]);
      }
    });
    $("#amountup-3").val($("#slider-range-3").slider("values", 0));
    $("#amountdown-3").val($("#slider-range-3").slider("values", 1));

    //The average margin Utilization% : 平均証拠金利用率 % ： 0, 10, 20, 30, 40, 50, 100
    var average_margin = [0, 10, 20, 30, 40, 50, 100];
    $("#slider-range-4").slider({
      range: true,
      min: 0,
      max: average_margin.length - 1,
      step:1,
      values: [1, 3],
      slide: function(event, ui) {
        $("#amountup-4").val(average_margin[ui.values[0]]);
        $("#amountdown-4").val(average_margin[ui.values[1]]);        
      }
    });
    $("#amountup-4").val(average_margin[$("#slider-range-4").slider("values", 0)]);
    $("#amountdown-4").val(average_margin[$("#slider-range-4").slider("values", 1)]);    
  });

  //button search groups
  $(".btnswitchsearch").click(function(){
    datatab = $(this).attr("data-tab");
    searchwrap = $(".showmoreoptionsearchwrap");
    searchwrap.removeClass("hidden");
    if (datatab=='searchname') {
      searchwrap.addClass("changecaret");      
    }else {
      searchwrap.removeClass("changecaret");
    }    
    $(".showmoreoptionsearchdetail").addClass("hidden");
    $("div[data-show='"+datatab+"']").removeClass("hidden");
    $(".btnswitchsearch").removeClass("actived");
    $(this).addClass("actived");  
  });

  $(document).mouseup(function (e){
    var container = $('.filters');
    if (!container.is(e.target)&& container.has(e.target).length === 0){
     $(".showmoreoptionsearchwrap ").removeClass('changecaret');
     $(".showmoreoptionsearchwrap ").addClass('hidden');
    }
  });

  //button search name & search advacend to show result 
  $(".btn-showresultadv").click(function(){
    $("#titlebarsearch").removeClass("rankingpageresult ").addClass("rankingpageresult");
    $("#titlebarsearch").removeClass("advanceresults").addClass("advanceresults");
    $("#mainlist").removeClass("rankingpageresult").addClass("rankingpageresult");
  });
  $(".btn-showresultname").click(function(){
    $("#titlebarsearch").removeClass("rankingpageresult").removeClass("advanceresults");
    $("#mainlist").removeClass("rankingpageresult");
  });

  //random avatar
  var avatars = Array(1,2,3,4,5,6,7,8,9);
  $(".randomAvatar").click(function(){
    var randomavatar = avatars[Math.floor(Math.random()*avatars.length)];
    dataurl = "resources/img/user/"+randomavatar+".jpg";
    //change avatar
    $(".box.memberinfo .mavatar > img").attr("src",dataurl);
    $(".currentavatarsetting > img").attr("src",dataurl);
    //change cover
    $(".box.memberinfo .mcoverwrap > .mcoverblur").attr("style","background-image:url('"+dataurl+"');");

  });

  //gallery select avatar
  $("ul.jfGallery li").click(function(){
    $("ul.jfGallery li").removeClass("selected");
    $(this).toggleClass("selected");
    dataurl = $(this).attr("data-url");
    
    //change avatar
    $(".box.memberinfo .mavatar > img").attr("src",dataurl);
    //change cover
    $(".box.memberinfo .mcoverwrap > .mcoverblur").attr("style","background-image:url('"+dataurl+"');");
  });

  //sortable
  $(function  () {
    $("ul.currency-pair-list").sortable({
        placeholder: "ui-state-highlight"
    });
  });  

  //Old coder
  // Load More Div
  var itemsCount = 0,
  itemsMax = $('.block-more-content .more-content-row').length;
  $('.block-more-content .more-content-row').hide();

  function showNextItems() {
    var pagination = 2;

    for (var i = itemsCount; i < (itemsCount + pagination); i++) {
      $('.block-more-content .more-content-row:eq(' + i + ')').fadeIn();
    }

    itemsCount += pagination;

    if (itemsCount > itemsMax) {
      $('.btn-block-load-more').hide();
      $('.end-result').show();
    }
  };

  showNextItems();

  $('.btn-block-load-more').on('click', function(e) {
    e.preventDefault();
    showNextItems();
  });


  // Number Only Custom
  $(".numberonly").keypress(function(e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      $("#errmsg").html("Number Only").show().fadeOut("slow");
      return false;
    }
  });

  // Tooltip
  $('body').tooltip({
    selector: '[data-toggle=tooltip]',
    container: "body"
  });
  // ---

  $('[data-toggle="popover"]').popover()
    // Popover Option
  $('html').on('click', function(e) {
    if (typeof $(e.target).data('toggle') == 'undefined' &&
      !$(e.target).parents().is('.popover.in')) {
      $('[data-toggle=popover]').popover('hide');
    }
  });

  $('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active')
  });

  $('.toggle-currency-list').click(function() {
    //$('.currency-list-more').toggle();
  })
  $('.btn-action').click(function() {
    $(this).parents('.btn-unfollow').hide();
    $('.btn-follow').fadeIn();
  })

  $('.btn-follow .btn').click(function() {
    $(this).parents('.btn-follow').hide();
    $('.btn-copy').fadeIn();
    $('.btn-follow').hide();
  })

  $('.btn-copy .btn').click(function() {
    $(this).parents('.btn-copy').hide();
    $('.btn-trade').fadeIn();
  })

  $('.btn-trade .btn').click(function() {
    $(this).parents('.btn-trade').hide();
    $('.btn-unfollow').fadeIn();
  })


  $('[data-toggle=tooltip]').tooltip();

  $('.stat-helper').hover(function() {
    $(this).parents('.stat-item, .box-stat').toggleClass('active');
  })

  $('.chart-stat-sum').hover(function() {
    $(this).toggleClass('active');
  })

  $('.btn-toggle-info').click(function() {
    $('.block-info').slideToggle();
    $(this).toggleClass('active');
  })

  // Ranking toggle detail

  $('.btn-toggle-detail').click(function() {
    $(this).parents('.guru-item-ranking').find('.guru-table-detail').toggle();
  })
  var now = new Date();
  $('select.selectpicker').selectpicker();
  $('.datepicker').datepicker({
    format: "yyyy/mm/dd",
    startDate: now,
    todayHighlight: true,
    language: 'ja'
  });
  $('.datepickernow').click(function(){
    $('.datepicker').datepicker({
      format: "yyyy/mm/dd",
      startDate: now,
      todayHighlight: true,
      language: 'ja'
    });    
  });

  // End Range Slider
  $('.btn-search-nickname').click(function() {
    $('.form-search-advance').hide();
    $('.form-search-nickname').slideToggle();
    $(this).toggleClass('active');
    $('.btn-search-advance').removeClass('active');
    $('.table-ranking-list .guru-advanced-result').hide();

    $(document.body).mousedown(function(event) {
      var target = $(event.target);
      if (!target.parents().andSelf().is('.form-search-nickname')) { // Clicked outside
       	$('.form-search-nickname').slideUp();
       	$('.btn-search-nickname').removeClass('active');
      }
    });
  })

  $('.btn-search-advance').click(function() {
    $('.form-search-nickname').hide();
    $('.form-search-advance').slideToggle();
    $(this).toggleClass('active');
    $('.btn-search-nickname').removeClass('active');
    $('.table-ranking-list .guru-advanced-result').show();

    $(document.body).mousedown(function(event) {
      var target = $(event.target);
      if (!target.parents().andSelf().is('.form-search-advance')) { // Clicked outside
       	$('.form-search-advance').slideUp();
       	$('.btn-search-advance').removeClass('active');
      }
    });
  })

  //fix 21character
  var customerName = $.trim($("#dropdownMemberLogged .guruname").text());
  if(customerName.length >= 22){
    customerName = customerName.substring(0, 21) + "...";
    $("#dropdownMemberLogged .guruname").html(customerName);
  }

})

  // manhpd fixed trade settings
  function updateNumberGuru(){
    currentlistnumber = $("ul[group='userlist'] li").length;
    addmorelistnumber = $("ul[group='userlistmore'] li").length;
    $(".box.copierlist .box-header span.badge").html(currentlistnumber);
    $(".box.followerlist #breadcrumb span.badge").html(addmorelistnumber);
  }
  
  function removeGuru(dataid){
    guru = $("li[data-id='"+dataid+"']").html();
    currentlist = $("ul[group='userlist']");
    addmorelist = $("ul[group='userlistmore']");

    addmorelist.append("<li class='guruitem' data-id='"+dataid+"'>"+guru+"</li>");
    $("ul[group='userlist'] li[data-id='"+dataid+"']").remove();  

    currentGuru(); 
    listtoaddGuru(); 
    updateNumberGuru()
  }
  function addGuru(dataid){
    guru = $("li[data-id='"+dataid+"']").html();
    currentlist = $("ul[group='userlist']");
    addmorelist = $("ul[group='userlistmore']");

    currentlist.append("<li class='guruitem' data-id='"+dataid+"'>"+guru+"</li>");
    $("ul[group='userlistmore'] li[data-id='"+dataid+"']").remove();   

    currentGuru();
    listtoaddGuru();
    updateNumberGuru()
  }

  function currentGuru(){
    countGuru = $("ul[group='userlist'] > li").length;
    if (countGuru==0) {
      $("#currentguru").removeClass("hidden");
    }else{
      $("#currentguru").addClass("hidden");
    }      
  }
  function listtoaddGuru(){
    countGuru = $("ul[group='userlistmore'] > li").length;
    if (countGuru==0) {
      $("#listtoaddGuru").removeClass("hidden");
    }else{
      $("#listtoaddGuru").addClass("hidden");
    }      
  }

