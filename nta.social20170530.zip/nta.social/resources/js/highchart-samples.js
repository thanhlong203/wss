// Line chart
// ======================================================================
$(function() {
  $('#highchart-1').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: [
      '01/25 1:00','01/25 7:00','01/25 13:00','01/25 19:00',
      '02/25 1:00','02/25 7:00','02/25 13:00','02/25 19:00',
      '03/25 1:00','03/25 7:00','03/25 13:00','03/25 19:00',
      '04/25 1:00','04/25 7:00','04/25 13:00','04/25 19:00',
      '05/25 1:00','05/25 7:00','05/25 13:00','05/25 19:00'
      ],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      },
      tickInterval: 6
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      opposite:true,
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	},
      	 formatter: function () {
                    return this.value + '%';
                }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
      headerFormat: '<b>{point.key}</b><br/>',
      pointFormat: '損益率:{point.y}%'
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: '週間',
      data: [
      18.2, 5.2, 26.5, 33.3,
      29.6,1.5,22.4,14.8,
      14,22,56,33,
      19,24,22,15,
      28,38,38.5,33]
    }]
  });

  // Chart 2
  $('#highchart-2').highcharts({
    title: {
      text: '1ヶ月 ',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: [
      	'01/25 7:00','02/25 7:00','03/25 7:00','04/25 7:00','05/25 7:00',
      	'06/25 7:00','07/25 7:00','08/25 7:00','09/25 7:00','09/25 7:00',
      	'11/25 7:00','12/25 7:00','13/25 7:00','14/25 7:00','15/25 7:00',
      	'16/25 7:00','17/25 7:00','18/25 7:00','19/25 7:00','20/25 7:00',
      ],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      },
      tickInterval: 6
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      opposite:true,
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	},
      	 formatter: function () {
                    return this.value + '%';
                }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
      headerFormat: '<b>{point.key}</b><br/>',
      pointFormat: '損益率:{point.y}%'
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: '1ヶ月',
      data: [
      8.2, 15.2, 36.5, 23.3, 8.3, 
      3.9, 19.6, 35, 45,55,
      33,12,22,41,40,
      10,8,22,24,11
      ]
    }]
  });

  // Chart 3
  $('#highchart-3').highcharts({
    title: {
      text: '3ヶ月 ',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: [
      '01/01', '01/02', '01/03', '01/04', '01/05','01/06', '01/07', '01/08', '01/09', '01/10','01/11', '01/12', '01/13', '01/14', '01/15','01/16', '01/17', '01/18', '01/19', '01/20',
      '02/01', '02/02', '02/03', '02/04', '02/05','02/06', '02/07', '02/08', '02/09', '02/10','02/11', '02/12', '02/13', '02/14', '02/15','02/16', '02/17', '02/18', '02/19', '02/20',
      '03/01', '03/02', '03/03', '03/04', '03/05','03/06', '03/07', '03/08', '03/09', '03/10','03/11', '03/12', '03/13', '03/14', '03/15','03/16', '03/17', '03/18', '03/19', '03/20'
      ],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      },
      tickInterval: 19
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      opposite:true,
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	},
      	 formatter: function () {
                    return this.value + '%';
                }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
      headerFormat: '<b>{point.key}</b><br/>',
      pointFormat: '損益率:{point.y}%'
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: '3ヶ月',
      data: [
      26.5, 35.3, 15.3, 3.9, 29.6,11,17,24,22,18,33,32,36,21,15,41,10,4,15,19,
      11,21,39,30,38,21,27,14,32,08,3,12,26,11,25,21,20,14,35,39,
      41,22,22,18,29,15,07,34,32,38,13,22,16,11,35,21,40,41,25,29,
      ]
    }]
  });

  // Chart 3
  $('#highchart-4').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: [
      '01/01', '01/02', '01/03', '01/04', '01/05','01/06', '01/07', '01/08', '01/09', '01/10','01/11', '01/12', '01/13', '01/14', '01/15','01/16', '01/17', '01/18', '01/19', '01/20',
      '02/01', '02/02', '02/03', '02/04', '02/05','02/06', '02/07', '02/08', '02/09', '02/10','02/11', '02/12', '02/13', '02/14', '02/15','02/16', '02/17', '02/18', '02/19', '02/20',
      '03/01', '03/02', '03/03', '03/04', '03/05','03/06', '03/07', '03/08', '03/09', '03/10','03/11', '03/12', '03/13', '03/14', '03/15','03/16', '03/17', '03/18', '03/19', '03/20',
      '04/01', '04/02', '04/03', '04/04', '04/05','04/06', '04/07', '04/08', '04/09', '04/10','04/11', '04/12', '04/13', '04/14', '04/15','04/16', '04/17', '04/18', '04/19', '04/20',
      '05/01', '05/02', '05/03', '05/04', '05/05','05/06', '05/07', '05/08', '05/09', '05/10','05/11', '05/12', '05/13', '05/14', '05/15','05/16', '05/17', '05/18', '05/19', '05/20',
      '06/01', '06/02', '06/03', '06/04', '06/05','06/06', '06/07', '06/08', '06/09', '06/10','06/11', '06/12', '06/13', '06/14', '06/15','06/16', '06/17', '06/18', '06/19', '06/20'
    
    ],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      },
      tickInterval: 29
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      opposite:true,
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	},
      	 formatter: function () {
                    return this.value + '%';
                }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: '6ヶ月',
      data: [
      26.5, 35.3, 15.3, 3.9, 29.6,11,17,24,22,18,33,32,36,21,15,41,10,4,15,19,
      11,21,39,30,38,21,27,14,32,08,3,12,26,11,25,21,20,14,35,39,
      41,22,22,18,29,15,07,34,32,38,13,22,16,11,35,21,40,41,25,29,26.5, 35.3, 15.3, 3.9, 29.6,11,17,24,22,18,33,32,36,21,15,41,10,4,15,19,
      11,21,39,30,38,21,27,14,32,08,3,12,26,11,25,21,20,14,35,39,
      41,22,22,18,29,15,07,34,32,38,13,22,16,11,35,21,40,41,25,29
      ]
    }]
  });

  // Chart 5
  $('#highchart-5').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: ['6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      },
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: 'USDJPY',
      data: [
      26.5, 35.3, 15.3, 3.9]
    }]
  });

  // Chart 6
  $('#highchart-6').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: ['6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA'
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: 'USDJPY',
      data: [8.2, 15.2, 36.5, 23.3, 8.3, 3.9, 19.6]
    }]
  });

  // Chart 7
  $('#highchart-7').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: ['6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA'
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: 'USDJPY',
      data: [8.2, 15.2, 36.5, 23.3, 8.3, 3.9, 19.6]
    }]
  });

  // Chart 8
  $('#highchart-8').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: ['6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA'
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: 'USDJPY',
      data: [8.2, 15.2, 36.5, 23.3, 8.3, 3.9, 19.6]
    }]
  });

  // Chart 9
  $('#highchart-9').highcharts({
    title: {
      text: 'USD',
      x: -20,
      style: {
        display: 'none'
      }
    },
    xAxis: {
      categories: ['6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00'],
      lineColor: '#F8E8BA',
      tickColor: '#F8E8BA'
    },
    colors: ['#EC9D3C'],
    chart: {
      backgroundColor: '#FFFFFF'
    },
    yAxis: {
      gridLineColor: '#F8E8BA',
      title: {
        text: 'USDJPY',
        style: {
          display: 'none'
        }
      },
      plotLines: [{
        value: 0,
        width: 1,
        color: '#808080'
      }]
    },
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle',
      borderWidth: 0,
      enabled: false
    },
    series: [{
      name: 'USDJPY',
      data: [8.2, 15.2, 36.5, 23.3, 8.3, 3.9, 19.6]
    }]
  });
});

// Spider chart
// ======================================================================
$(function() {

  $('#highchart-spider-1').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });

  $('#highchart-spider-2').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });

  $('#highchart-spider-3').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-4').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-5').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-6').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-7').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-8').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
  $('#highchart-spider-9').highcharts({

    chart: {
      polar: true,
      type: 'line'
    },

    title: {
      style: {
        display: 'none'
      }
    },

    pane: {
      size: '80%'
    },

    xAxis: {
      categories: ['★の数', '損益率', 'ベンチメンバー', '勝率',
        'プロフィットファクター', '最大損失率'
      ],
      tickmarkPlacement: 'on',
      lineWidth: 0
    },

    yAxis: {
      gridLineInterpolation: 'polygon',
      lineWidth: 0,
      min: 0
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      }
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },

    legend: {
      align: 'bottom',
      verticalAlign: 'top',
      y: 70,
      layout: 'vertical',
      enabled: false
    },

    series: [{
      name: 'USDJPY',
      data: [43000, 19000, 60000, 35000, 17000, 10000],
      pointPlacement: 'on',
      style: {
        fontFamily: 'Arial'
      }
    }]

  });
});



// bar chart
// ======================================================================
$(function() {
  // Create the chart
  $('#bar-chart-1').highcharts({
    chart: {
      type: 'column'
    },
    title: {
      text: 'Browser market shares. January, 2015 to May, 2015',
      style: {
        display: 'none'
      }
    },
    xAxis: {
      type: 'category',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },
    yAxis: {
      title: {
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },

    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      enabled: false
    },
    plotOptions: {
      series: {
        color: '#FF0000',
        borderWidth: 0,
        dataLabels: {
          enabled: false
        }
      }
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}pips'
    },
    series: [{
      name: "Currency",
      colorByPoint: true,
      data: [{
        name: "USDJPY",
        y: 56.33,

        color: '#335C7B'
      }, {
        name: "JPYHKD",
        y: 24.03,

        color: '#335C7B'
      }, {
        name: "USDEUR",
        y: 10.38,

        color: '#335C7B'
      }, {
        name: "USDGBP",
        y: 0.91,

        color: '#335C7B'
      }, {
        name: "USDJPY",
        y: -20,

        color: '#DD3B2C'
      }]
    }]
  });

  // Create the chart
  $('#bar-chart-2').highcharts({
    chart: {
      type: 'column'
    },
    title: {
      text: 'Browser market shares. January, 2015 to May, 2015',
      style: {
        display: 'none'
      }
    },
    xAxis: {
      type: 'category',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },
    yAxis: {
      title: {
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },

    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      enabled: false
    },
    plotOptions: {
      series: {
        color: '#FF0000',
        borderWidth: 0,
        dataLabels: {
          enabled: false
        }
      }
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}pips'
    },
    series: [{
      name: "Currency",
      colorByPoint: true,
      data: [{
        name: "USDJPY",
        y: 26.33,

        color: '#335C7B'
      }, {
        name: "JPYHKD",
        y: 34.03,

        color: '#335C7B'
      }, {
        name: "USDEUR",
        y: 41.38,

        color: '#335C7B'
      }, {
        name: "USDGBP",
        y: -10.91,

        color: '#DD3B2C'
      }, {
        name: "USDJPY",
        y: 10,

        color: '#335C7B'
      }]
    }]
  });

  // Create the chart
  $('#bar-chart-3').highcharts({
    chart: {
      type: 'column'
    },
    title: {
      text: 'Browser market shares. January, 2015 to May, 2015',
      style: {
        display: 'none'
      }
    },
    xAxis: {
      type: 'category',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },
    yAxis: {
      title: {
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },

    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      enabled: false
    },
    plotOptions: {
      series: {
        color: '#FF0000',
        borderWidth: 0,
        dataLabels: {
          enabled: false
        }
      }
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}pips'
    },
    series: [{
      name: "Currency",
      colorByPoint: true,
      data: [{
        name: "USDJPY",
        y: 16.33,

        color: '#335C7B'
      }, {
        name: "JPYHKD",
        y: 34.03,

        color: '#335C7B'
      }, {
        name: "USDEUR",
        y: 21.38,

        color: '#335C7B'
      }, {
        name: "USDGBP",
        y: 5.91,

        color: '#335C7B'
      }, {
        name: "USDJPY",
        y: 12,

        color: '#335C7B'
      }]
    }]
  });

  // Create the chart
  $('#bar-chart-4').highcharts({
    chart: {
      type: 'column'
    },
    title: {
      text: '',
      style: {
        display: 'none'
      }
    },
    xAxis: {
      type: 'category',
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },
    yAxis: {
      title: {
        style: {
          display: 'none'
        }
      },
      labels: {
      	style: {
      		fontFamily: 'Meiryo'
      	}
      }
    },

    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    legend: {
      enabled: false
    },
    plotOptions: {
      series: {
        color: '#FF0000',
        borderWidth: 0,
        dataLabels: {
          enabled: false
        }
      }
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}pips'
    },
    series: [{
      name: "Currency",
      colorByPoint: true,
      data: [{
        name: "USDJPY",
        y: 13.33,

        color: '#335C7B'
      }, {
        name: "JPYHKD",
        y: 17.03,

        color: '#335C7B'
      }, {
        name: "USDEUR",
        y: 31.38,

        color: '#335C7B'
      }, {
        name: "USDGBP",
        y: 40.91,

        color: '#335C7B'
      }, {
        name: "USDJPY",
        y: -10,

        color: '#DD3B2C'
      }]
    }]
  });
});


// Pie chart
// ======================================================================
$(function() {
  // Create the chart
  $('#pie-chart-1').highcharts({
    chart: {
      type: 'pie',
      margin: [0, 0, 20, 0],
      spacingTop: 0,
      spacingBottom: 0,
      spacingLeft: 0,
      spacingRight: 0
    },
    plotOptions: {
      pie: {
        size: '100%',
        center: ['50%', '50%'],
        dataLabels: {
          enabled: false,
        },
        showInLegend: true
      }
    },

    title: {
      text: null
    },
    exporting: {
      enabled: false
    },
    "credits": {
      "enabled": false
    },


    
    legend:{
    	itemStyle: {
    		fontWeight:'400',
    		fontFamily: 'Meiryo',
    		fontSize: '11px'
    	}
    },
    series: [{
      size: '85%',
      innerSize: '75%',
      borderColor: "transparent",
      name: 'AAA',
      data: [{
        y: 12,
        color: '#607D8A',
        name: 'USDJPY'
      }, {
        y: 10,
        color: '#229D72',
        name: 'EURGBP'
      }, {
        y: 20,
        color: '#DD3B2C',
        name: 'JPYGBP'
      }]
    }],
    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
      headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}%'
    }
  });

  // Create the chart
  $('#pie-chart-2').highcharts({
    chart: {
      type: 'pie',
      margin: [0, 0, 20, 0],
      spacingTop: 0,
      spacingBottom: 0,
      spacingLeft: 0,
      spacingRight: 0
    },
    plotOptions: {
      pie: {
        size: '100%',
        center: ['50%', '50%'],
        dataLabels: {
          enabled: false,
        },
        showInLegend: true
      }
    },
    legend:{
    	itemStyle: {
    		fontWeight:'400',
    		fontFamily: 'Meiryo',
    		fontSize: '11px'
    	}
    },

    title: {
      text: null
    },
    exporting: {
      enabled: false
    },
    "credits": {
      "enabled": false
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}%'
    },
    series: [{
      size: '85%',
      innerSize: '75%',
      borderColor: "transparent",
      data: [{
        y: 20,
        color: '#607D8A',
        name: 'USDJPY'
      }, {
        y: 18,
        color: '#229D72',
        name: 'EURGBP'
      }, {
        y: 7,
        color: '#E67C33',
        name: 'JPYEUR'
      }, {
        y: 51,
        color: '#DD3B2C',
        name: 'JPYGBP'
      }]
    }]
  });

  // Create the chart
  $('#pie-chart-3').highcharts({
    chart: {
      type: 'pie',
      margin: [0, 0, 20, 0],
      spacingTop: 0,
      spacingBottom: 0,
      spacingLeft: 0,
      spacingRight: 0
    },
    legend:{
    	itemStyle: {
    		fontWeight:'400',
    		fontFamily: 'Meiryo',
    		fontSize: '11px'
    	}
    },
    plotOptions: {
      pie: {
        size: '100%',
        center: ['50%', '50%'],
        dataLabels: {
          enabled: false,
        },
        showInLegend: true
      }
    },

    title: {
      text: null
    },
    exporting: {
      enabled: false
    },
    "credits": {
      "enabled": false
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
       headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}%'
    },
    series: [{
      size: '85%',
      innerSize: '75%',
      borderColor: "transparent",
      data: [{
        y: 6,
        color: '#607D8A',
        name: 'USDJPY'
      }, {
        y: 14,
        color: '#229D72',
        name: 'EURGBP'
      }, {
        y: 26,
        color: '#E67C33',
        name: 'JPYEUR'
      }, {
        y: 22,
        color: '#DD3B2C',
        name: 'JPYGBP'
      }]
    }]
  });

  // Create the chart
  $('#pie-chart-4').highcharts({
    chart: {
      type: 'pie',
      margin: [0, 0, 20, 0],
      spacingTop: 0,
      spacingBottom: 0,
      spacingLeft: 0,
      spacingRight: 0
    },
    legend:{
    	itemStyle: {
    		fontWeight:'400',
    		fontFamily: 'Meiryo',
    		fontSize: '11px'
    	}
    },
    plotOptions: {
      pie: {
        size: '100%',
        center: ['50%', '50%'],
        dataLabels: {
          enabled: false,
        },
        showInLegend: true
      }
    },

    title: {
      text: null
    },
    exporting: {
      enabled: false
    },
    "credits": {
      "enabled": false
    },

    tooltip: {
      backgroundColor: '#E7AD23',
      borderColor: 'black',
      borderRadius: 5,
      borderWidth: 0,
      style: {
        fontFamily: 'Arial',
        color: '#fff'
      },
      headerFormat: '<b>{point.key}</b><br>',
      pointFormat: '{point.y}%'
    },
    series: [{
      size: '85%',
      innerSize: '75%',
      borderColor: "transparent",
      data: [{
        y: 16,
        color: '#607D8A',
        name: 'USDJPY'
      }, {
        y: 15,
        color: '#229D72',
        name: 'EURGBP'
      }, {
        y: 12,
        color: '#E67C33',
        name: 'JPYEUR'
      }, {
        y: 8,
        color: '#DD3B2C',
        name: 'JPYGBP'
      }]
    }]
  });
});

// Fix Chart Resize
jQuery(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function(e) { // on tab selection event
  jQuery(".contains-chart").each(function() { // target each element with the .contains-chart class
    var chart = jQuery(this).highcharts(); // target the chart itself
    chart.reflow() // reflow that chart
  });
})

